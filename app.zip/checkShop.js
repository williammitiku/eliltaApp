import React, { useState, useEffect } from "react";
import { useNavigation } from '@react-navigation/native';
import {
  StyleSheet,
  ActivityIndicator,
  Text,
  TextInput,
  View,
  TouchableOpacity,
  Image,
  Alert,
} from "react-native";
import AsyncStorage from '@react-native-async-storage/async-storage';

const CheckShop = () => {
  const navigation = useNavigation();
  const [emailFromStorage, setEmailFromStorage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [shop, setShop] = useState(null); // New state for storing shop data

  useEffect(() => {
    const getEmailFromStorage = async () => {
      try {
        const storedDataString = await AsyncStorage.getItem('userData');
        const storedData = JSON.parse(storedDataString);
        const userEmail = storedData.user.email;
        setEmailFromStorage(userEmail);
      } catch (error) {
        console.error('Error retrieving data from AsyncStorage:', error);
      }
    };

    getEmailFromStorage();
  }, []);

  const handleSubmit = async () => {
    if (!phoneNumber) {
      Alert.alert('Please enter a phone number.');
      return;
    }

    try {
      setIsLoading(true);

      const response = await fetch('https://eliltatradingadmin.com/api/shop/verifyShopExistence', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ phoneNumber }),
      });

      if (!response.ok) {
        throw new Error('Network response was not ok.');
      }

      const data = await response.json();

      if (data.status === 'success') {
        setShop(data.shop); // Set the shop data if found
        await AsyncStorage.setItem('shopInfo', JSON.stringify(data.shop));
      } else {
        setShop(null); // Clear shop data if not found
      }
    } catch (error) {
      console.error('Error verifying shop existence:', error);
      Alert.alert('Error verifying shop existence. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Image
        source={require('./assets/check.png')} 
        style={styles.logo}
        resizeMode="contain"
      />

      <Text style={styles.label}>Enter PhoneNumber or Shop Code:</Text>
        
      <TextInput
        style={styles.input}
        placeholder="Phone Number"
        value={phoneNumber}
        onChangeText={(text) => {
          if (/^\d*$/.test(text)) {
            const sanitizedText = text.replace(/\D/g, '');
            if ((sanitizedText.startsWith('9') || sanitizedText.startsWith('7')) &&
              sanitizedText.length <= 9) {
              setPhoneNumber(sanitizedText.slice(0, 9));
            } else {
              if (sanitizedText.length > 9) {
                Alert.alert('Phone number should not exceed 9 digits');
              } else if (sanitizedText.length > 0) {
                Alert.alert('Phone number should start with 9 or 7');
              }
            }
          }
        }}
        keyboardType="numeric"
      />

      <TouchableOpacity
        onPress={handleSubmit}
        style={styles.rightButton}
        disabled={isLoading}
      >
        {isLoading ? (
          <ActivityIndicator size="small" color="white" />
        ) : (
          <Text style={{ color: "white", textAlign: "center" }}>Search Shop</Text>
        )}
      </TouchableOpacity>

      {/* Conditionally render the search result or the "Create New Shop" card */}
      {shop ? (
        <View style={styles.shopContainer}>
          <Text style={styles.shopInfo}>Shop Name: {shop.shopName}</Text>
          <Text style={styles.shopInfo}>Shop Channel Type: {shop.channelType}</Text>
          <Text style={styles.shopInfo}>Shop Type: {shop.shopType}</Text>

          <TouchableOpacity
            onPress={() => navigation.navigate('Form')}
            style={styles.updateButton}
          >
            <Text style={{ color: "white", textAlign: "center" }}>Do you have Sale Here?</Text>
          </TouchableOpacity>
        </View>
      ) : (
        !isLoading && (
          <View style={styles.createNewShopContainer}>
            <Text style={styles.noShopText}>Shop with {phoneNumber} not found</Text>
            <TouchableOpacity
              onPress={() => navigation.navigate('RegisterShop', { phoneNumber: phoneNumber })}
              style={styles.createButton}
            >
              <Text style={{ color: "white", textAlign: "center" }}>Create New Shop</Text>
            </TouchableOpacity>
          </View>
        )
      )}

      {/* Footer with "See Your Accounts" and "See Your Stats" hyperlinks */}
      <View style={styles.footer}>
        <TouchableOpacity
          onPress={() => navigation.navigate('Accounts')}
          style={styles.footerLink}
        >
          <Text style={styles.footerText}>See Your Accounts</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => navigation.navigate('Dashboard')}
          style={styles.footerLink}
        >
          <Text style={styles.footerText}>See Your Stats</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default CheckShop;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 10,
  },
  logo: {
    width: 200,
    height: 100,
    marginBottom: 20,
  },
  label: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 10,
    color: "#333",
    width: '100%'
  },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
    width: "100%",
  },
  rightButton: {
    backgroundColor: "black",
    color: "white",
    padding: 8,
    borderRadius: 5,
    textAlign: "center",
    marginTop: 0,
    width: "100%",
  },
  shopContainer: {
    marginTop: 20,
    padding: 20,
    backgroundColor: '#f9f9f9',
    borderRadius: 10,
    width: '100%',
  },
  shopInfo: {
    fontSize: 16,
    marginBottom: 10,
  },
  updateButton: {
    backgroundColor: "blue",
    color: "white",
    padding: 8,
    borderRadius: 5,
    textAlign: "center",
    marginTop: 10,
    width: "100%",
  },
  createNewShopContainer: {
    marginTop: 20,
    padding: 20,
    backgroundColor: '#f9f9f9',
    borderRadius: 10,
    width: '100%',
    alignItems: 'center',
  },
  noShopText: {
    fontSize: 16,
    color: 'red',
    marginBottom: 10,
  },
  createButton: {
    backgroundColor: "green",
    color: "white",
    padding: 8,
    borderRadius: 5,
    textAlign: "center",
    marginTop: 10,
    width: "100%",
  },
  footer: {
    position: 'absolute',
    bottom: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
    paddingHorizontal: 20,
  },
  footerLink: {
    padding: 10,
  },
  footerText: {
    color: 'blue',
    textDecorationLine: 'underline',
  },
});
